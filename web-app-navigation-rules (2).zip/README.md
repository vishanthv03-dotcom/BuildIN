# Builden - Civil Engineering Marketplace

A modern SaaS marketplace connecting civil engineering professionals with project owners. Post projects, receive bids, and collaborate on infrastructure projects.

## 🎯 Project Overview

**Builden** is a full-stack Next.js 16 application with Supabase backend that enables:
- ✅ Project owners to post civil engineering work
- ✅ Professionals to discover and bid on projects
- ✅ Real-time messaging and communication
- ✅ Professional verification and credentials
- ✅ Reviews and ratings system
- ✅ Secure authentication and data protection

## 🚀 Quick Links

### Getting Started
- **Local Development**: See `LOCAL_SETUP.md`
- **Deploy to Vercel**: See `VERCEL_QUICKSTART.md` (5 minutes)
- **Full Deployment Guide**: See `DEPLOYMENT.md`
- **Pre-Deployment Checklist**: See `DEPLOY_CHECKLIST.md`

### Deployment Status
📍 **Ready for Production Deployment**
- All environment files configured
- Supabase schema created and tested
- Next.js build optimized
- RLS policies secured

## 📋 Technology Stack

| Category | Technology |
|----------|-----------|
| **Frontend** | Next.js 16, React 19, TypeScript |
| **Styling** | Tailwind CSS v4, shadcn/ui |
| **Backend** | Next.js API Routes |
| **Database** | Supabase PostgreSQL |
| **Authentication** | Supabase Auth |
| **Deployment** | Vercel |
| **Storage** | Supabase Storage |

## 🏗️ Project Structure

```
builden/
├── app/
│   ├── (auth)/               # Authentication routes
│   ├── dashboard/            # Role-based dashboards
│   ├── projects/             # Project listing & creation
│   ├── professionals/        # Professional directory
│   ├── api/                  # API endpoints
│   ├── page.tsx             # Landing page
│   └── layout.tsx           # Root layout with navbar
├── components/
│   ├── navbar.tsx           # Header with Builden logo
│   ├── ui/                  # shadcn/ui components
│   └── ...
├── lib/
│   ├── supabase/            # Supabase client setup
│   ├── db.ts                # Database utilities
│   └── utils.ts
├── public/
│   └── images/              # Assets (Builden logo)
├── .env.local              # Local dev environment
├── .env.production         # Production config reference
├── .env.example            # Environment template
├── vercel.json             # Vercel deployment config
└── DEPLOYMENT.md           # Deployment guide
```

## 🛠️ Local Development

### Prerequisites
- Node.js 18+ (20.x recommended)
- pnpm (or npm/yarn)
- Supabase account (free tier works)
- GitHub account (for deployment)

### Setup

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd builden
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Create `.env.local`**
   ```bash
   cp .env.example .env.local
   # Then edit .env.local with your Supabase credentials
   ```

4. **Run dev server**
   ```bash
   pnpm dev
   ```

5. **Open in browser**
   - Landing page: http://localhost:3000
   - Sign up: http://localhost:3000/auth/sign-up
   - Projects: http://localhost:3000/projects

## 🌐 Deployment to Vercel

### ⚡ Quick Deploy (5 minutes)
See **`VERCEL_QUICKSTART.md`**

### 📝 Detailed Guide (with screenshots)
See **`DEPLOYMENT.md`**

### ✅ Pre-flight Checklist
See **`DEPLOY_CHECKLIST.md`**

### Key Steps
1. Push code to GitHub
2. Import project in Vercel
3. Add 3 Supabase env variables
4. Deploy
5. Update Supabase redirect URLs

**Your app will be live in ~5 minutes!**

## 📚 Documentation

| Document | Purpose | Read Time |
|----------|---------|-----------|
| `VERCEL_QUICKSTART.md` | Fast deployment guide | 5 min |
| `DEPLOYMENT.md` | Complete setup with troubleshooting | 20 min |
| `DEPLOY_CHECKLIST.md` | Pre-deployment verification | 10 min |
| `DEPLOYMENT_SUMMARY.md` | Overview of setup & status | 10 min |

## 🔑 Environment Variables

### Required (Supabase)
```env
NEXT_PUBLIC_SUPABASE_URL=https://[project].supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
```

### Optional
```env
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000/auth/callback
```

See `.env.example` for full reference.

## 📊 Database Schema

14 tables with Row Level Security:
- **profiles** - User accounts (clients, professionals)
- **professional_profiles** - Extended pro information
- **projects** - Project listings
- **bids** - Bids on projects
- **messages** - Real-time chat
- **reviews** - Ratings and feedback
- **skills** - Professional skills
- **certifications** - Professional certs
- **portfolios** - Work samples
- **notifications** - User notifications
- **transactions** - Payment tracking
- **documents** - File uploads
- **verifications** - Professional verification
- **activity_logs** - Audit trail

## 🔐 Security Features

- ✅ Row Level Security (RLS) on all tables
- ✅ Email-confirmed authentication
- ✅ Service role key for admin operations
- ✅ User scoping on all queries
- ✅ Encrypted sensitive data
- ✅ Secure session management

## 🎨 User Roles

### Client
- Post civil engineering projects
- Receive and review bids
- Communicate with professionals
- Leave reviews
- Track project progress

### Professional
- Browse available projects
- Submit competitive bids
- Showcase portfolio & credentials
- Communicate with clients
- Build reputation

### Platform Owner
- Manage professionals
- Verify credentials
- Handle disputes
- View analytics

## 📱 Key Pages

| Route | Purpose | Access |
|-------|---------|--------|
| `/` | Landing page | Public |
| `/auth/sign-up` | Account creation | Public |
| `/auth/login` | Sign in | Public |
| `/projects` | Browse projects | Public |
| `/professionals` | Browse professionals | Public |
| `/projects/new` | Create project | Client only |
| `/projects/[id]` | Project detail + bid | All users |
| `/dashboard/client` | Client dashboard | Client only |
| `/dashboard/professional` | Pro dashboard | Professional only |
| `/profile/setup` | Complete profile | New users |

## 🧪 Testing

### Manual Testing
1. Sign up with test email
2. Confirm email (check inbox or Supabase logs)
3. Complete profile setup
4. Create a test project
5. Switch account and bid on project
6. Accept bid and view in dashboard

### Check Database
```bash
# View data in Supabase Dashboard
# Project → SQL Editor → Browse tables
```

## 📈 Performance

- **Build Time**: ~2-5 minutes
- **Page Load**: < 2 seconds (Vercel CDN)
- **Database Queries**: Optimized with indexes
- **Images**: Optimized with Next.js Image component

## 🐛 Troubleshooting

### Build Fails Locally
```bash
pnpm install  # Reinstall dependencies
pnpm build    # Try building
```

### Database Connection Error
- Verify Supabase URL is correct
- Check anon key matches project
- Verify RLS policies allow read access

### Auth Not Working
- Verify email confirmation is enabled
- Check redirect URLs in Supabase
- Check browser cookies not blocked

See `DEPLOYMENT.md` troubleshooting section for more.

## 🚀 Phase 2 Features (Prepared)

Ready for future expansion:
- Escrow payment processing
- Subscription plans  
- Premium listings
- Advanced analytics dashboard
- Automated invoicing

## 📞 Support

- **Deployment Issues**: See `DEPLOYMENT.md` troubleshooting
- **Next.js Questions**: [nextjs.org/docs](https://nextjs.org/docs)
- **Supabase Help**: [supabase.com/docs](https://supabase.com/docs)
- **Vercel Support**: [vercel.com/support](https://vercel.com/support)

## 📄 License

Built with v0.app

## 🎉 Ready to Deploy?

Start with **`VERCEL_QUICKSTART.md`** and you'll be live in 5 minutes!

```bash
# Quick deploy checklist:
1. git push origin main          # Push code to GitHub
2. Go to vercel.com/dashboard   # Import project
3. Add 3 env variables           # From Supabase
4. Click Deploy                  # Wait 2-5 minutes
5. Update Supabase URLs          # Auth redirect URLs
6. Visit your live app! 🎉
```

---

**Built with**: Next.js 16 | Supabase | Vercel  
**Status**: ✅ Production Ready  
**Last Updated**: June 6, 2026
