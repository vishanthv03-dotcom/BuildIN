'use server'

import { createClient } from '@/lib/supabase/server'

// Profile operations
export async function getProfile(userId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single()
  
  if (error) throw error
  return data
}

export async function updateProfile(userId: string, data: Record<string, any>) {
  const supabase = await createClient()
  const { data: updated, error } = await supabase
    .from('profiles')
    .update(data)
    .eq('id', userId)
    .select()
    .single()
  
  if (error) throw error
  return updated
}

export async function getProfessionalProfile(userId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('professional_profiles')
    .select('*')
    .eq('id', userId)
    .single()
  
  if (error?.code === 'PGRST116') return null // Not found
  if (error) throw error
  return data
}

export async function createProfessionalProfile(userId: string, profileData: Record<string, any>) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('professional_profiles')
    .insert({ id: userId, ...profileData })
    .select()
    .single()
  
  if (error) throw error
  return data
}

// Project operations
export async function getProjects(limit = 12, offset = 0) {
  const supabase = await createClient()
  const { data, error, count } = await supabase
    .from('projects')
    .select('*', { count: 'exact' })
    .eq('status', 'open')
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1)
  
  if (error) throw error
  return { projects: data || [], total: count || 0 }
}

export async function getProject(projectId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('projects')
    .select(`
      *,
      client:client_id (*)
    `)
    .eq('id', projectId)
    .single()
  
  if (error) throw error
  return data
}

export async function createProject(clientId: string, projectData: Record<string, any>) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('projects')
    .insert({ client_id: clientId, ...projectData })
    .select()
    .single()
  
  if (error) throw error
  return data
}

export async function getClientProjects(clientId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('projects')
    .select('*')
    .eq('client_id', clientId)
    .order('created_at', { ascending: false })
  
  if (error) throw error
  return data || []
}

// Bid operations
export async function createBid(projectId: string, professionalId: string, bidData: Record<string, any>) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('bids')
    .insert({
      project_id: projectId,
      professional_id: professionalId,
      ...bidData
    })
    .select()
    .single()
  
  if (error) throw error
  return data
}

export async function getProjectBids(projectId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('bids')
    .select(`
      *,
      professional:professional_id (
        id,
        full_name,
        avatar_url,
        role
      )
    `)
    .eq('project_id', projectId)
    .order('created_at', { ascending: false })
  
  if (error) throw error
  return data || []
}

export async function getProfessionalBids(professionalId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('bids')
    .select(`
      *,
      project:project_id (
        id,
        title,
        budget_min,
        budget_max
      )
    `)
    .eq('professional_id', professionalId)
    .order('created_at', { ascending: false })
  
  if (error) throw error
  return data || []
}

// Messaging operations
export async function sendMessage(senderId: string, recipientId: string, content: string, projectId?: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('messages')
    .insert({
      sender_id: senderId,
      recipient_id: recipientId,
      content,
      project_id: projectId || null
    })
    .select()
    .single()
  
  if (error) throw error
  return data
}

export async function getConversation(userId: string, otherUserId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('messages')
    .select('*')
    .or(`and(sender_id.eq.${userId},recipient_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},recipient_id.eq.${userId})`)
    .order('created_at', { ascending: true })
  
  if (error) throw error
  return data || []
}

// Review operations
export async function createReview(reviewerId: string, revieweeId: string, projectId: string, reviewData: Record<string, any>) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('reviews')
    .insert({
      reviewer_id: reviewerId,
      reviewee_id: revieweeId,
      project_id: projectId,
      ...reviewData
    })
    .select()
    .single()
  
  if (error) throw error
  return data
}

export async function getProfileReviews(profileId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('reviews')
    .select(`
      *,
      reviewer:reviewer_id (
        id,
        full_name,
        avatar_url
      )
    `)
    .eq('reviewee_id', profileId)
    .order('created_at', { ascending: false })
  
  if (error) throw error
  return data || []
}

// Notification operations
export async function getNotifications(userId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
  
  if (error) throw error
  return data || []
}
