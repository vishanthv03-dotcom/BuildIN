# Vercel Deployment - 5 Minute Quick Start

## TL;DR - Deploy in 5 Steps

### Step 1: Get Your Supabase Credentials
Go to your **Supabase Dashboard** → **Project Settings** → **API**

Copy these values:
- **Project URL** (e.g., `https://lbubsjkckufmqbmlhplx.supabase.co`)
- **Anon Key** (public, under "Project API Keys")
- **Service Role Key** (secret, under "Project API Keys")

### Step 2: Push Code to GitHub
```bash
git add .
git commit -m "Ready for Vercel deployment"
git push origin main
```

### Step 3: Import Project to Vercel
1. Go to https://vercel.com/dashboard
2. Click **Add New** → **Project**
3. Select your GitHub repository
4. Click **Import**

### Step 4: Add Environment Variables
In the "Environment Variables" section, add:

| Name | Value | Scope |
|------|-------|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | Your Supabase project URL | Production, Preview, Development |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Your anon key | Production, Preview, Development |
| `SUPABASE_SERVICE_ROLE_KEY` | Your service role key | Production, Preview, Development |

Then click **Deploy**

### Step 5: Update Supabase Redirect URLs
1. Go to Supabase → **Authentication** → **URL Configuration**
2. Add your Vercel URL to **Redirect URLs**:
   ```
   https://[your-project].vercel.app/auth/callback
   https://[your-project].vercel.app/
   ```

**Done!** 🎉 Your app is now live.

---

## Environment Variables Explained

### What Gets Set Where?

**In Vercel Dashboard:**
```
NEXT_PUBLIC_SUPABASE_URL=https://lbubsjkckufmqbmlhplx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**`NEXT_PUBLIC_*` Variables:**
- Safe to expose to browser/client
- Used by Supabase client (`@supabase/ssr`)
- Anyone can see these in network requests

**`SUPABASE_SERVICE_ROLE_KEY`:**
- Secret - only for server-side code
- NEVER expose to browser
- Used for admin operations, RLS bypass
- Stored securely in Vercel

---

## Find Your Supabase Credentials

### Location in Supabase Dashboard

**Project URL:**
```
Supabase Dashboard
  ↓
Your Project
  ↓
Settings (⚙️) icon
  ↓
API
  ↓
Project URL (copy this)
```

**Anon Key:**
```
Supabase Dashboard
  ↓
Your Project
  ↓
Settings → API
  ↓
Project API Keys
  ↓
Copy "anon/public" key
```

**Service Role Key:**
```
Supabase Dashboard
  ↓
Your Project
  ↓
Settings → API
  ↓
Project API Keys
  ↓
Copy "service_role" key (⚠️ SECRET)
```

---

## Verify Deployment Works

### Test 1: Landing Page
- Visit your Vercel URL (e.g., `https://builden-xxxx.vercel.app`)
- See ✅ Builden logo in navbar
- See ✅ Hero section with buttons

### Test 2: Sign Up
- Click "Get Started Free"
- Sign up with test email
- Confirm email (check inbox)
- Should redirect to profile setup
- ✅ Profile created automatically

### Test 3: Browse Projects
- Click "Browse Projects"
- See list of projects (empty if none created)
- ✅ Page loads without errors

### Test 4: Create Project
- Log in as a client
- Go to `/projects/new`
- Fill form and create a project
- ✅ Project appears in list

---

## Troubleshooting

### Deployment Failed
**Check:** Vercel Dashboard → Deployments → Click failed build
**Look for:** Error messages in logs
**Fix:** Push corrected code to GitHub

### White screen / 500 error
**Check:** Vercel Logs (Dashboard → Deployments → Logs)
**Common causes:**
- Missing environment variables
- Wrong Supabase keys
- Database connection failed

**Fix:**
1. Verify all 3 env vars are set in Vercel
2. Verify they match your Supabase project
3. Redeploy: Click **Redeploy** in Deployments

### Sign up doesn't work
**Check:** Supabase → Authentication → Logs

**Common causes:**
- Redirect URL not updated in Supabase
- Email confirmation not sent

**Fix:**
1. Add your Vercel URL to Supabase → Auth → URL Configuration
2. Redeploy

### 404 on project pages
**Check:** Database has projects
**Fix:** Create test projects in `/projects/new`

---

## Environment Variables At A Glance

| Variable | Where | Value | Safe for Client? |
|----------|-------|-------|------------------|
| `NEXT_PUBLIC_SUPABASE_URL` | Vercel | Your Supabase URL | ✅ Yes |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Vercel | Public anon key | ✅ Yes |
| `SUPABASE_SERVICE_ROLE_KEY` | Vercel (Secret) | Service role key | ❌ No |

---

## Next Steps

- **Full guide:** See `DEPLOYMENT.md` for detailed instructions
- **Checklist:** Use `DEPLOY_CHECKLIST.md` before going live
- **Monitoring:** Set up analytics in Vercel Dashboard
- **Scaling:** Monitor Supabase usage as you grow

---

**Questions?** Check `DEPLOYMENT.md` for troubleshooting section.

**Ready to deploy?** Follow the 5 steps above! 🚀
