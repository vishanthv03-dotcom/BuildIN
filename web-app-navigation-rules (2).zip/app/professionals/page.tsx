'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Navbar } from '@/components/navbar'
import { createClient } from '@/lib/supabase/client'

interface Professional {
  id: string
  full_name: string
  avatar_url?: string
  bio?: string
  email: string
}

interface ProfessionalProfile {
  id: string
  company_name?: string
  years_experience?: number
  specializations?: string[]
  hourly_rate?: number
}

export default function ProfessionalsPage() {
  const [professionals, setProfessionals] = useState<(Professional & { profile?: ProfessionalProfile })[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    const fetchProfessionals = async () => {
      const supabase = createClient()

      const { data, error } = await supabase
        .from('profiles')
        .select(`
          id,
          full_name,
          avatar_url,
          bio,
          email,
          role
        `)
        .eq('role', 'professional')
        .order('created_at', { ascending: false })

      if (!error && data) {
        // Fetch professional profiles
        const withProfiles = await Promise.all(
          data.map(async (prof) => {
            const { data: profData } = await supabase
              .from('professional_profiles')
              .select('*')
              .eq('id', prof.id)
              .single()
            return { ...prof, profile: profData }
          })
        )
        setProfessionals(withProfiles)
      }
      setLoading(false)
    }

    fetchProfessionals()
  }, [])

  const filteredProfessionals = professionals.filter((prof) =>
    prof.full_name?.toLowerCase().includes(search.toLowerCase()) ||
    prof.profile?.company_name?.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-4">Browse Professionals</h1>
          <Input
            placeholder="Search by name or company..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-md"
          />
        </div>

        {loading ? (
          <p>Loading professionals...</p>
        ) : filteredProfessionals.length === 0 ? (
          <p className="text-muted-foreground">No professionals found</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProfessionals.map((prof) => (
              <Link key={prof.id} href={`/professionals/${prof.id}`}>
                <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <CardTitle>{prof.full_name}</CardTitle>
                    {prof.profile?.company_name && (
                      <CardDescription>{prof.profile.company_name}</CardDescription>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {prof.bio && <p className="text-sm text-muted-foreground">{prof.bio}</p>}

                    {prof.profile?.specializations && prof.profile.specializations.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-2">Specializations</p>
                        <div className="flex flex-wrap gap-2">
                          {prof.profile.specializations.slice(0, 3).map((spec) => (
                            <Badge key={spec} variant="secondary" className="text-xs">
                              {spec}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {prof.profile?.years_experience && (
                      <p className="text-sm">
                        <span className="font-semibold">{prof.profile.years_experience}</span> years experience
                      </p>
                    )}

                    {prof.profile?.hourly_rate && (
                      <p className="text-lg font-bold">${prof.profile.hourly_rate}/hour</p>
                    )}
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
