'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function DashboardPage() {
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const checkUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push('/auth/login')
        return
      }

      // Check if profile exists
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single()

      if (!profile) {
        router.push('/profile/setup')
        return
      }

      // Redirect to role-specific dashboard
      if (profile.role === 'professional') {
        router.push('/dashboard/professional')
      } else {
        router.push('/dashboard/client')
      }
    }

    checkUser()
  }, [router, supabase])

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <p className="text-foreground">Loading...</p>
    </div>
  )
}
