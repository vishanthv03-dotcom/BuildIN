'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'

export default function ProfessionalDashboard() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [bids, setBids] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const loadDashboard = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push('/auth/login')
        return
      }

      setUser(user)

      // Get profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single()

      if (!profileData) {
        router.push('/profile/setup')
        return
      }

      if (profileData.role !== 'professional') {
        router.push('/dashboard/client')
        return
      }

      setProfile(profileData)

      // Get professional's bids
      const { data: bidsData } = await supabase
        .from('bids')
        .select(
          `
          *,
          projects (
            id,
            title,
            description,
            budget_min,
            budget_max,
            status
          )
        `
        )
        .eq('professional_id', user.id)
        .order('created_at', { ascending: false })

      setBids(bidsData || [])
      setLoading(false)
    }

    loadDashboard()
  }, [supabase, router])

  const getBidStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800'
      case 'accepted':
        return 'bg-green-100 text-green-800'
      case 'rejected':
        return 'bg-red-100 text-red-800'
      case 'withdrawn':
        return 'bg-gray-100 text-gray-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 py-12">
          <p className="text-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              Welcome, {profile?.full_name || 'Professional'}!
            </h1>
            <p className="text-muted-foreground mt-2">
              Browse available projects and manage your bids
            </p>
          </div>
        </div>

        {profile && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">{bids.length}</CardTitle>
                <CardDescription>Total Bids</CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">
                  {bids.filter((b) => b.status === 'accepted').length}
                </CardTitle>
                <CardDescription>Accepted Bids</CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">${profile.hourly_rate || 0}/hr</CardTitle>
                <CardDescription>Hourly Rate</CardDescription>
              </CardHeader>
            </Card>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Your Bids</CardTitle>
                <CardDescription>Track and manage all your project bids</CardDescription>
              </CardHeader>
              <CardContent>
                {bids.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">
                      You haven&apos;t submitted any bids yet
                    </p>
                    <Link href="/projects">
                      <Button variant="outline">Browse Available Projects</Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {bids.map((bid) => (
                      <Link
                        key={bid.id}
                        href={`/projects/${bid.project_id}`}
                      >
                        <div className="p-4 border border-border rounded-lg hover:bg-muted transition-colors">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-semibold text-foreground">
                                {(bid.projects as any)?.title || 'Project'}
                              </h3>
                              <p className="text-sm text-muted-foreground mt-1">
                                Bid: ${bid.bid_amount} • {bid.bid_duration_days || '—'} days
                              </p>
                            </div>
                            <Badge className={getBidStatusColor(bid.status)}>
                              {bid.status}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {bid.proposal_text?.substring(0, 80)}...
                          </p>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle>Profile Completion</CardTitle>
                <CardDescription>Complete your profile to attract more clients</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm">
                  <div className="flex justify-between mb-1">
                    <span className="text-foreground font-medium">Skills & Experience</span>
                    <span className="text-muted-foreground">0%</span>
                  </div>
                  <div className="h-2 bg-muted rounded">
                    <div className="h-full w-0 bg-primary rounded"></div>
                  </div>
                </div>

                <div className="text-sm">
                  <div className="flex justify-between mb-1">
                    <span className="text-foreground font-medium">Certifications</span>
                    <span className="text-muted-foreground">0%</span>
                  </div>
                  <div className="h-2 bg-muted rounded">
                    <div className="h-full w-0 bg-primary rounded"></div>
                  </div>
                </div>

                <div className="text-sm">
                  <div className="flex justify-between mb-1">
                    <span className="text-foreground font-medium">Portfolio</span>
                    <span className="text-muted-foreground">0%</span>
                  </div>
                  <div className="h-2 bg-muted rounded">
                    <div className="h-full w-0 bg-primary rounded"></div>
                  </div>
                </div>

                <Link href="/profile/settings">
                  <Button variant="outline" size="sm" className="w-full mt-4">
                    Update Profile
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
