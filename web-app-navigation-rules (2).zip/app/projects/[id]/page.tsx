'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Navbar } from '@/components/navbar'
import { createClient } from '@/lib/supabase/client'

interface Project {
  id: string
  title: string
  description: string
  category: string
  location: string
  budget_min: number
  budget_max: number
  urgency: string
  timeline_days: number
  required_skills: string[]
  created_at: string
  client: {
    id: string
    full_name: string
    avatar_url: string
  }
}

interface Bid {
  id: string
  bid_amount: number
  proposal_text: string
  status: string
  created_at: string
  professional: {
    id: string
    full_name: string
    avatar_url: string
  }
}

export default function ProjectPage() {
  const params = useParams()
  const projectId = params.id as string
  const [project, setProject] = useState<Project | null>(null)
  const [bids, setBids] = useState<Bid[]>([])
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const [showBidForm, setShowBidForm] = useState(false)
  const [bidData, setBidData] = useState({ amount: '', duration: '', proposal: '' })
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()

      // Get current user
      const {
        data: { user: authUser },
      } = await supabase.auth.getUser()
      setUser(authUser)

      // Get project details
      const { data: projectData, error: projectError } = await supabase
        .from('projects')
        .select(
          `*,
          client:client_id(id, full_name, avatar_url)`
        )
        .eq('id', projectId)
        .single()

      if (!projectError) {
        setProject(projectData)
      }

      // Get project bids
      const { data: bidsData, error: bidsError } = await supabase
        .from('bids')
        .select(
          `*,
          professional:professional_id(id, full_name, avatar_url)`
        )
        .eq('project_id', projectId)
        .order('created_at', { ascending: false })

      if (!bidsError) {
        setBids(bidsData || [])
      }

      setLoading(false)
    }

    fetchData()
  }, [projectId])

  const handleBidSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !bidData.amount || !bidData.proposal) {
      alert('Please fill in all required fields')
      return
    }

    setSubmitting(true)
    try {
      const supabase = createClient()
      const { data, error } = await supabase
        .from('bids')
        .insert({
          project_id: projectId,
          professional_id: user.id,
          bid_amount: parseFloat(bidData.amount),
          bid_duration_days: bidData.duration ? parseInt(bidData.duration) : null,
          proposal_text: bidData.proposal,
          status: 'pending',
        })
        .select(
          `*,
          professional:professional_id(id, full_name, avatar_url)`
        )
        .single()

      if (error) {
        throw error
      }

      setBids([data, ...bids])
      setBidData({ amount: '', duration: '', proposal: '' })
      setShowBidForm(false)
      alert('Bid submitted successfully!')
    } catch (error) {
      console.error('Error submitting bid:', error)
      alert('Failed to submit bid')
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-12">
          <p>Loading...</p>
        </div>
      </div>
    )
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-12">
          <p>Project not found</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Project Details */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-3xl">{project.title}</CardTitle>
                    <CardDescription className="mt-2">
                      Posted {new Date(project.created_at).toLocaleDateString()}
                    </CardDescription>
                  </div>
                  <Badge variant="outline">{project.urgency}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-2">Description</h3>
                  <p className="text-muted-foreground whitespace-pre-wrap">{project.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {project.budget_min && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Budget Range</p>
                      <p className="text-lg font-semibold">
                        ${project.budget_min.toLocaleString()} - ${project.budget_max.toLocaleString()}
                      </p>
                    </div>
                  )}
                  {project.timeline_days && (
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Timeline</p>
                      <p className="text-lg font-semibold">{project.timeline_days} days</p>
                    </div>
                  )}
                </div>

                {project.location && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Location</p>
                    <p className="text-base">{project.location}</p>
                  </div>
                )}

                {project.required_skills.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-2">Required Skills</p>
                    <div className="flex flex-wrap gap-2">
                      {project.required_skills.map((skill) => (
                        <Badge key={skill} variant="secondary">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Client Info */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <p className="text-sm text-muted-foreground">Posted by</p>
                    <p className="font-semibold">{project.client.full_name}</p>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </div>

          {/* Bid Section */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Submit a Bid</CardTitle>
              </CardHeader>
              <CardContent>
                {user ? (
                  <>
                    <p className="text-sm text-muted-foreground mb-4">
                      {bids.length} bid{bids.length !== 1 ? 's' : ''} submitted
                    </p>
                    {!showBidForm ? (
                      <Button className="w-full" onClick={() => setShowBidForm(true)}>
                        Submit Bid
                      </Button>
                    ) : (
                      <form onSubmit={handleBidSubmit} className="space-y-4">
                        <div>
                          <Label htmlFor="amount">Bid Amount ($) *</Label>
                          <Input
                            id="amount"
                            type="number"
                            placeholder="0.00"
                            value={bidData.amount}
                            onChange={(e) => setBidData({ ...bidData, amount: e.target.value })}
                            required
                          />
                        </div>

                        <div>
                          <Label htmlFor="duration">Duration (Days)</Label>
                          <Input
                            id="duration"
                            type="number"
                            placeholder="30"
                            value={bidData.duration}
                            onChange={(e) => setBidData({ ...bidData, duration: e.target.value })}
                          />
                        </div>

                        <div>
                          <Label htmlFor="proposal">Proposal *</Label>
                          <Textarea
                            id="proposal"
                            placeholder="Explain your approach and why you're a good fit..."
                            rows={4}
                            value={bidData.proposal}
                            onChange={(e) => setBidData({ ...bidData, proposal: e.target.value })}
                            required
                          />
                        </div>

                        <Button type="submit" className="w-full" disabled={submitting}>
                          {submitting ? 'Submitting...' : 'Submit Bid'}
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          className="w-full"
                          onClick={() => setShowBidForm(false)}
                        >
                          Cancel
                        </Button>
                      </form>
                    )}
                  </>
                ) : (
                  <div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Sign in to submit a bid
                    </p>
                    <Link href="/auth/login">
                      <Button className="w-full">Sign In</Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Bids List */}
        {bids.length > 0 && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6">Bids</h2>
            <div className="space-y-4">
              {bids.map((bid) => (
                <Card key={bid.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-semibold">{bid.professional.full_name}</p>
                        <p className="text-sm text-muted-foreground mt-1">{bid.proposal_text}</p>
                        <p className="text-xs text-muted-foreground mt-2">
                          {new Date(bid.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold">${bid.bid_amount.toLocaleString()}</p>
                        <Badge variant="outline" className="mt-2">
                          {bid.status}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
