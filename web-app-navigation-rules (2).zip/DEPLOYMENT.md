# Builden Deployment Guide - Vercel

## Overview
This guide walks you through deploying the Builden civil engineering marketplace to Vercel with Supabase integration.

## Prerequisites
- GitHub account with your Builden repository
- Vercel account (free tier works)
- Supabase project already created and configured
- All environment variables ready (see .env.example)

## Step 1: Prepare Your Repository

### 1.1 Make sure your `.env.local` is NOT committed to git
```bash
# Verify .env.local is in .gitignore
echo ".env.local" >> .gitignore
git add .gitignore
git commit -m "Update .gitignore to exclude environment files"
git push origin main
```

### 1.2 Verify all code is committed
```bash
git status  # Should show "nothing to commit, working tree clean"
git push origin main
```

## Step 2: Connect Vercel to Your GitHub Repository

### 2.1 Sign in to Vercel Dashboard
Go to https://vercel.com/dashboard

### 2.2 Click "Add New Project"
- Click the **Add New** button
- Select **Project** from the dropdown

### 2.3 Import Your Repository
- Select **GitHub** as the source
- Search for and select your `builden` repository
- Click **Import**

### 2.4 Configure Project Settings
- **Project Name**: `builden` (or your preferred name)
- **Framework Preset**: Select **Next.js** (should auto-detect)
- **Root Directory**: Keep default (.)
- **Build Command**: Keep default (`next build`)
- **Output Directory**: Keep default (`.next`)
- **Install Command**: Keep default (`npm install` or `pnpm install`)

## Step 3: Add Environment Variables to Vercel

Your Supabase environment variables are already set in Vercel via the integration, but you need to ensure they're configured for the right environment.

### 3.1 Add Environment Variables via Vercel Dashboard

After clicking **Import**, you'll see the "Configure Project" step.

**Click on "Environment Variables"** and add the following:

#### Required Variables (Copy from your Supabase project):

1. **NEXT_PUBLIC_SUPABASE_URL**
   - Value: Your Supabase project URL (e.g., `https://[project-ref].supabase.co`)
   - Find it: Supabase Dashboard → Project Settings → API → Project URL

2. **NEXT_PUBLIC_SUPABASE_ANON_KEY**
   - Value: Your public anon key (safe for client-side)
   - Find it: Supabase Dashboard → Project Settings → API → Project API Keys → anon/public

3. **SUPABASE_SERVICE_ROLE_KEY**
   - Value: Your service role key (secret - for server-side only)
   - Find it: Supabase Dashboard → Project Settings → API → Project API Keys → service_role
   - **IMPORTANT**: This is secret - never expose to clients

4. **POSTGRES_URL** (optional but recommended)
   - Value: Your Supabase PostgreSQL connection string
   - Find it: Supabase Dashboard → Project Settings → Database → Connection Pooling (Session mode)

**Environment Variable Scope:**
- Select scope: **Production, Preview, Development**
- Click **Add** for each variable

### 3.2 Apply to All Environments
For each variable, ensure it's added to:
- ✅ Production
- ✅ Preview
- ✅ Development

## Step 4: Deploy Your Project

### 4.1 Click Deploy
After adding all environment variables:
- Click the **Deploy** button (blue button at bottom right)
- Vercel will automatically trigger your first deployment

### 4.2 Monitor the Build
- You'll see build logs in real-time
- Watch for any build errors (if there are errors, fix them locally and push)
- Once complete, you'll see ✅ deployment successful

### 4.3 Get Your Production URL
- Vercel will provide your live URL (e.g., `https://builden-xxxx.vercel.app`)
- Click **Visit** to view your live application

## Step 5: Update Supabase Auth Redirect URLs

After your app is deployed, update Supabase to allow redirects from your Vercel domain.

### 5.1 Go to Supabase Dashboard
- Project → Authentication → URL Configuration

### 5.2 Add Your Vercel URLs
Add both to **Redirect URLs**:
- `https://your-deployment-url.vercel.app/auth/callback`
- `https://your-deployment-url.vercel.app/`

Example:
```
https://builden-xxxx.vercel.app/auth/callback
https://builden-xxxx.vercel.app/
```

## Step 6: Verify Deployment

### 6.1 Test the Landing Page
- Visit your Vercel deployment URL
- Verify the Builden logo appears in the navbar
- Check all sections load correctly

### 6.2 Test Authentication
- Click "Get Started Free"
- Try signing up with a test email
- Verify you're redirected after email confirmation
- Check that your profile was created automatically

### 6.3 Test Core Features
- Browse projects: `/projects`
- Browse professionals: `/professionals`
- Create a test project: `/projects/new` (as client)
- Submit a test bid: Click on any project and bid on it (as professional)

## Step 7: Configure Production Settings

### 7.1 Set Domain (Optional)
If you have a custom domain:
- Vercel Dashboard → Project Settings → Domains
- Add your domain and follow DNS configuration

### 7.2 Enable Analytics (Optional)
Your project includes Vercel Analytics:
- It's automatically enabled
- View analytics in Vercel Dashboard → Analytics

### 7.3 Set Automatic Deployments
By default, every push to `main` triggers a deployment:
- You can configure this in: Project Settings → Git
- Disable auto-deploy if you prefer manual deployments

## Environment Variables Reference

| Variable | Required | Scope | Description |
|----------|----------|-------|-------------|
| `NEXT_PUBLIC_SUPABASE_URL` | Yes | Public | Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Yes | Public | Public anon key for client-side |
| `SUPABASE_SERVICE_ROLE_KEY` | Yes | Secret | Service role key for server-side |
| `POSTGRES_URL` | No | Secret | Postgres connection string |
| `NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL` | No | Public | Auth redirect (auto-set by Next.js) |

## Troubleshooting

### Build Fails with Missing Dependencies
```
Error: Module not found
```
**Solution**: Push latest `pnpm-lock.yaml` or `package-lock.json` to git
```bash
git add pnpm-lock.yaml
git commit -m "Update lock file"
git push
```

### Authentication Not Working
```
Error: Failed to exchange code for session
```
**Solution**: 
1. Verify `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` are set in Vercel
2. Add your Vercel URL to Supabase → Auth → URL Configuration
3. Redeploy: Click **Deploy** in Vercel

### Database Queries Fail
```
Error: RLS policy violation
```
**Solution**:
1. Verify `SUPABASE_SERVICE_ROLE_KEY` is set in Vercel (Environment Variables)
2. Check RLS policies in Supabase → SQL Editor
3. Ensure auth user exists before creating records

### Environment Variables Not Loading
**Solution**:
1. Redeploy after adding env vars: Vercel → Deployments → Click latest → **Redeploy**
2. Or: Project Settings → Git → Trigger Deploy from `main`

## Rolling Back a Deployment

If something breaks:
1. Go to Vercel Dashboard → Deployments
2. Find the last working deployment
3. Click the three dots (...) → Promote to Production
4. Your previous version is now live

## Monitoring & Logs

### View Deployment Logs
- Vercel Dashboard → Deployments → Click on deployment → View Logs

### View Application Errors
- Vercel Dashboard → Settings → Analytics → Error Summary
- Or check Supabase dashboard for database issues

## Next Steps

### Phase 2 Features (When Ready)
- Escrow payments integration
- Subscription plans
- Premium listings
- Advanced analytics dashboard
- Automated invoicing

To enable: Update feature flags and add relevant API routes.

## Support

- **Vercel Docs**: https://vercel.com/docs
- **Next.js Docs**: https://nextjs.org/docs
- **Supabase Docs**: https://supabase.com/docs
- **Builden Issues**: Check GitHub Issues in your repository

---

**Deployment Complete!** 🎉 Your Builden marketplace is now live.
