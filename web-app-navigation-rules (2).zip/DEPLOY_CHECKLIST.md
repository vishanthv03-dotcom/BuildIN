# Builden Deployment Checklist

Complete this checklist before deploying to Vercel.

## Pre-Deployment (Local)

### Code & Repository
- [ ] All code committed to git: `git status` shows clean working tree
- [ ] Latest changes pushed to GitHub: `git push origin main`
- [ ] `.env.local` is NOT committed (verify in `.gitignore`)
- [ ] `node_modules/` is in `.gitignore`
- [ ] No console.log debug statements in production code

### Build Verification
- [ ] Local build succeeds: `pnpm build`
- [ ] No TypeScript errors: `pnpm tsc --noEmit`
- [ ] No ESLint errors: `pnpm lint` (if configured)
- [ ] Dev server starts without errors: `pnpm dev`

### Dependencies
- [ ] All dependencies listed in `package.json`
- [ ] Lock file committed (`pnpm-lock.yaml` or `package-lock.json`)
- [ ] Latest versions installed: `pnpm install`

## Vercel Configuration

### Account Setup
- [ ] Vercel account created and logged in
- [ ] GitHub account connected to Vercel

### Environment Variables (in Vercel Dashboard)
Required variables - Get these from your Supabase project settings:

**Production Environment:**
- [ ] `NEXT_PUBLIC_SUPABASE_URL` = `https://[project-ref].supabase.co`
- [ ] `NEXT_PUBLIC_SUPABASE_ANON_KEY` = Your public anon key
- [ ] `SUPABASE_SERVICE_ROLE_KEY` = Your service role key (secret)

**Preview Environment:**
- [ ] Same variables as Production

**Development Environment:**
- [ ] Same variables as Production

All three should be identical for testing purposes.

### Project Settings
- [ ] Framework: **Next.js** (auto-detected)
- [ ] Build Command: `next build`
- [ ] Output Directory: `.next`
- [ ] Install Command: `pnpm install` or `npm install`
- [ ] Node Version: **20.x** or later

## Supabase Configuration

### Database
- [ ] Database schema created: `profiles`, `projects`, `bids`, etc.
- [ ] RLS (Row Level Security) policies enabled
- [ ] Auth triggers created for auto-profile generation

### Authentication
- [ ] Email/password authentication enabled
- [ ] Email confirmation required (for security)
- [ ] Redirect URLs updated in Supabase Auth settings:
  - [ ] `https://your-vercel-domain.vercel.app/auth/callback`
  - [ ] `https://your-vercel-domain.vercel.app/`

### Storage
- [ ] Supabase Storage bucket created (if using file uploads)
- [ ] RLS policies set for storage bucket

## Deployment Steps

### 1. Connect Repository
- [ ] Go to https://vercel.com/dashboard
- [ ] Click "Add New" → "Project"
- [ ] Select your GitHub repository
- [ ] Click "Import"

### 2. Configure Project
- [ ] Project name set correctly
- [ ] Framework: **Next.js**
- [ ] Root directory: `.`
- [ ] Build command verified

### 3. Add Environment Variables
- [ ] All three variables added and scoped to Production/Preview/Development
- [ ] Double-check values (no typos, correct keys)
- [ ] Click "Add" for each variable

### 4. Deploy
- [ ] Click the blue **Deploy** button
- [ ] Monitor build logs (should complete in 2-5 minutes)
- [ ] Watch for build errors
- [ ] Verify deployment shows ✅ success

### 5. Post-Deployment
- [ ] Visit your Vercel URL in browser
- [ ] Verify Builden logo appears in navbar
- [ ] All pages load without 404 errors
- [ ] Sign-up flow works (test with temporary email)
- [ ] Email confirmation works
- [ ] Dashboard loads after confirming email

### 6. Update Supabase Redirect URLs
- [ ] Go to Supabase Dashboard → Authentication → URL Configuration
- [ ] Add your Vercel deployment URL to **Redirect URLs**
- [ ] Format: `https://your-domain.vercel.app/auth/callback`

## Testing (Production)

### Authentication
- [ ] Sign up with new account
- [ ] Email confirmation link works
- [ ] Redirected to dashboard after confirmation
- [ ] Can log in with existing credentials
- [ ] Logout works and redirects to home

### User Roles
- [ ] **Client** role: Can post projects, see bids
- [ ] **Professional** role: Can browse projects, submit bids
- [ ] **Platform Owner** role: Can access admin functions

### Core Marketplace
- [ ] Browse projects page loads with real data
- [ ] Browse professionals page loads
- [ ] Project detail page shows all information
- [ ] Can submit a bid on a project (as professional)
- [ ] Bid appears in client dashboard

### Database & RLS
- [ ] Only authorized users see their own data
- [ ] Users cannot access other users' projects
- [ ] Professional data is publicly visible
- [ ] Messages between users are private

## Performance & Monitoring

### Vercel Dashboard
- [ ] Check deployment time (should be < 5 min)
- [ ] Monitor error logs
- [ ] Enable Analytics if desired
- [ ] Set up automatic deployments (optional)

### Monitoring Ongoing
- [ ] Set up error tracking (optional: Sentry, Vercel Analytics)
- [ ] Monitor database usage in Supabase
- [ ] Check for slow queries in Supabase logs

## Post-Deployment (Optional)

### Domain Setup
- [ ] Custom domain configured (if purchased)
- [ ] SSL certificate auto-provisioned by Vercel
- [ ] DNS records updated

### Backups
- [ ] Database backups configured in Supabase
- [ ] Regular backup schedule set

### Scaling
- [ ] Monitor Vercel usage (serverless functions)
- [ ] Monitor Supabase usage (database, auth)
- [ ] Set up email notifications for alerts

## Troubleshooting

If deployment fails:

### Build Errors
1. Check build logs in Vercel Dashboard
2. Fix errors locally: `pnpm build`
3. Commit fix: `git add . && git commit -m "Fix build" && git push`
4. Vercel auto-redeploys on push

### Runtime Errors
1. Check Vercel logs: Dashboard → Deployments → Logs
2. Check Supabase logs: Project → Logs → Edge Functions / API
3. Verify environment variables are set

### Database Connection Issues
1. Verify `SUPABASE_SERVICE_ROLE_KEY` is set in Vercel
2. Test connection locally first
3. Check Supabase connection limits

### Auth Not Working
1. Verify Supabase redirect URLs are updated
2. Verify environment variables are set
3. Clear browser cookies and try again
4. Check Supabase → Auth → Logs for errors

---

**Checklist Complete!** 🎉 Your deployment is ready to go live.

For detailed instructions, see **DEPLOYMENT.md**
